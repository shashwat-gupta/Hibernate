package com.newPackage;

import javax.persistence.Entity;

@Entity
public class VisitngDoctor extends Doctor {

	int visitingHours;
	int visitingCharges;
	
	public VisitngDoctor() {
	}

	
	public VisitngDoctor(int dId, String name, String specialization, int visitingHours, int visitingCharges) {
		super(dId, name, specialization);
		this.visitingHours = visitingHours;
		this.visitingCharges = visitingCharges;
	}



	public int getVisitingHours() {
		return visitingHours;
	}

	public void setVisitingHours(int visitingHours) {
		this.visitingHours = visitingHours;
	}

	public int getVisitingCharges() {
		return visitingCharges;
	}

	public void setVisitingCharges(int visitingCharges) {
		this.visitingCharges = visitingCharges;
	}

	@Override
	public String toString() {
		return "VisitngDoctor [visitingHours=" + visitingHours + ", visitingCharges=" + visitingCharges + "]";
	}
	
	
}
