package com.newPackage;


import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ch=1;
		while(ch!=0)
		{
		System.out.println("Chooose the option you want to Do");
		System.out.println("1 : Add Doctors of Different type");
		System.out.println("2 : Display Doctors From Database");
		System.out.println("3 : Update Name Of The Doctor");
		System.out.println("4 : Display Doctor Of Particular Specialization");
		System.out.println("5 : Display Doctors of Cardiologist and Pediatrician");
		ch = Integer.parseInt(sc.next());
		
		switch(ch)
		{
		case 1:
				MainClass ma1 = new MainClass();
				ma1.addDoctors();
				break;
		
		case 2:
				MainClass ma2 = new MainClass();
				ma2.DisplayAll();
				break;
		
		case 3:
				MainClass ma3 = new MainClass();
				ma3.update();
				break;
		
		case 4:
				MainClass ma4 = new MainClass();
				ma4.displayonspec();
				break;
		
		case 5: 
				MainClass ma5 = new MainClass();
				ma5.dispCardandPaed();
				break;
				
		case 0 :
				System.exit(0);
				break;
		}
		
		}
		
	}
	
	public void addDoctors()
	{	Scanner sc = new Scanner(System.in);
		System.out.println("Enter if a Regular or Visiting Docotr");
		String type= sc.next();
		if(type.equalsIgnoreCase("Regular"))
		{
			System.out.println("Enter your Id ");
			int id = Integer.parseInt(sc.next());
			System.out.println("Enter Your Name");
			String name = sc.next();
			System.out.println("Enter Your Salary");
			int salary = Integer.parseInt(sc.next());
			System.out.println("Enter No. of Leaves");
			int nol = Integer.parseInt(sc.next());
			System.out.println("Enter Your Specialization");
			String spec = sc.next();
			
			Doctor d = new Doctor(id,name,spec);
			RegularDoctor rd = new RegularDoctor(id, name,spec,nol, salary);
			
			AnnotationConfiguration cfg = new AnnotationConfiguration();
			
			SessionFactory factory = cfg.configure().buildSessionFactory();
			
			Session session = factory.openSession();
			
			Transaction t = session.beginTransaction();
			
			session.save(rd);
		
			t.commit();
			
			Session session1 = factory.openSession();
			
			Transaction t1 = session1.beginTransaction();
			
			session1.save(d);
			
			t1.commit();
		}
		else if(type.equalsIgnoreCase("Visiting"))
		{
		
			System.out.println("Enter your Id ");
			int id = Integer.parseInt(sc.next());
			System.out.println("Enter Your Name");
			String name = sc.next();
			System.out.println("Enter Your Specialization");
			String spec = sc.next();
			System.out.println("Enter Your Visiting Hours");
			int hours = Integer.parseInt(sc.next());
			System.out.println("Enter Your Visiting Charges");
			int charges = Integer.parseInt(sc.next());
			
			VisitngDoctor vd = new VisitngDoctor(id, name, spec,hours,charges);
			
			Doctor d = new Doctor(id,name,spec);
			
			AnnotationConfiguration cfg = new AnnotationConfiguration();
			
			SessionFactory factory = cfg.configure().buildSessionFactory();
			
			Session session = factory.openSession();
			
			Transaction t = session.beginTransaction();
					session.save(vd);
					
					
			t.commit();
			Session session1 = factory.openSession();
			
			Transaction t1 = session1.beginTransaction();
			
			session1.save(d);
			
			t1.commit();
		}
	}
	
	public void DisplayAll()
	{
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		
		SessionFactory factory = cfg.configure().buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction t = session.beginTransaction();
		
		Query query = session.createQuery("From Doctor" );
		
		List<Doctor> dlist = query.list();
		
		for(Doctor d : dlist)
		{
			System.out.println(d);
		}
		
		
	}
	
	public void update()
	{	
		Scanner sc = new Scanner(System.in);
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		
		SessionFactory factory = cfg.configure().buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction t = session.beginTransaction();
		System.out.println("Enter Old Name");
		String oname = sc.next();
		System.out.println("Enter New Name");
		String nname = sc.next();
		System.out.println("Enter Type Regular or Visiting");
		String type = sc.next();
		if(type.equalsIgnoreCase("Regular"))
		{
		Query query = session.createQuery("Update Doctor set name=? where name=?");
		
		Query query1 = session.createQuery("Update RegularDoctor set name=? where name=?");
		
		query.setString(0, nname);
		query.setString(1, oname);
		query.executeUpdate();
		query1.setString(0, nname);
		query1.setString(1, oname);
		query1.executeUpdate();
		
		t.commit();
		}
		if(type.equalsIgnoreCase("Visiting"))
		{
		Query query = session.createQuery("Update Doctor set name=? where name=?");
		
		Query query1 = session.createQuery("Update VisitngDoctor set name=? where name=?");
		
		query.setString(0, nname);
		query.setString(1, oname);
		query.executeUpdate();
		query1.setString(0, nname);
		query1.setString(1, oname);
		query1.executeUpdate();
		
		t.commit();
		}
		System.out.println("Name Updated");
	}
	
	public void displayonspec()
	{	
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		
		SessionFactory factory = cfg.configure().buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction t = session.beginTransaction();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Specialization");
		String type1 = sc.next();
		
		
	
			Query query = session.createQuery("From Doctor where specialization=?");
			query.setString(0, type1);
			
			List<Doctor> vdlist = query.list();
			
			for(Doctor vd : vdlist)
			{
				System.out.println(vd);
			}
	}
	
	public void dispCardandPaed()
	{	
		AnnotationConfiguration cfg = new AnnotationConfiguration();
		
		SessionFactory factory = cfg.configure().buildSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction t = session.beginTransaction();
		Criteria criteria = session.createCriteria(Doctor.class);
		Criterion cr1 = Restrictions.like("specialization","Cardiologist");
		Criterion cr2 = Restrictions.like("specialization", "Pediatrician");
		criteria.add(Restrictions.or(cr1, cr2));
		List<Doctor> dlist = criteria.list();
		
		for(Doctor d : dlist)
		{
			System.out.println(d);
		}
		t.commit();
	}
}
